********************************************************

  Give I18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Give updates.
  
  Keep custom Give translations in /wp-content/languages/give/
  
  If you would like to translate, help, or improve a translation.
  
  Email info@wordmpress.com OR Coming soon:
  join our WP-Translations Community at
  https://www.transifex.com/projects/p/give/

  More info at http://wp-translations.org/

********************************************************
